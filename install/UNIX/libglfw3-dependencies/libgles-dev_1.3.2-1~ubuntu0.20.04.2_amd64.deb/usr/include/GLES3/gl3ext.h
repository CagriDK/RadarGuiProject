#ifndef __gl3ext_h_
#define __gl3ext_h_

/* 
 * This file is intentionally empty and is provided for source compatibility
 * with Mesa.
 */

#endif /* __gl3ext_h_ */
